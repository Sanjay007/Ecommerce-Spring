package com.ecom.app.model;

/**
 * Created by rajeevkumarsingh on 07/12/17.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
