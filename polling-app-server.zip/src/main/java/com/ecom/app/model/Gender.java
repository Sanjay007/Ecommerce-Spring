package com.ecom.app.model;

public enum Gender {
MALE,FEMALE,OTHERS
}
