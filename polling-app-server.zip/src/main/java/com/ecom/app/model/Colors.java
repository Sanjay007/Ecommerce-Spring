package com.ecom.app.model;

public enum Colors {
RED,GREEN,YELLOW
}
